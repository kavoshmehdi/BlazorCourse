# bootstrap4-rtl
Bootstrap 4 RTL Theme

usage:
```html
<!-- Original Bootstrap 4.x -->
<link rel="stylesheet" href="bootstrap.css">

<!-- Bootstrap RTL Theme -->
<link rel="stylesheet" href="bootstrap-rtl.css">
```


Install with [npm](https://www.npmjs.com/): npm install @ghalamborm/bootstrap4-rtl


﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BethanysPieShopHRM.Shared
{
    public enum ExpenseStatus
    {
        Open,
        Approved,
        Denied,
        Pending
    }
}

﻿namespace BethanysPieShopHRM.Shared
{
    public enum MaritalStatus
    {
        Married,
        Single,
        Other
    }
}
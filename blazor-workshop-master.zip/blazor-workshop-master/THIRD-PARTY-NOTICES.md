This repo contains materials from third parties, supplied under the following licenses:

* Bootstrap CSS library
  Copyright 2011-2018 The Bootstrap Authors
  Copyright 2011-2018 Twitter, Inc.
  Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)

* Quicksand font
  Copyright 2011 The Quicksand Project Authors (https://github.com/andrew-paglinawan/QuicksandFamily),
  with Reserved Font Name. Licensed under SIL (http://scripts.sil.org/OFL)

* meaty.jpg
  Photo by Matteo Vistocco on Unsplash (https://unsplash.com/license)
* cheese.jpg
  Photo by Evelyn on Unsplash (https://unsplash.com/license)
* pepperoni.jpg
  Photo by Alan Hardman on Unsplash (https://unsplash.com/license)
* margherita.jpg
  Photo by rawpixel on Unsplash (https://unsplash.com/license)
* salad.jpg
  Photo by Jose Soriano on Unsplash (https://unsplash.com/license)
* mushroom.jpg
  Photo by Lavi Perchik on Unsplash (https://unsplash.com/license)
* brit.jpg
  Photo by Chris Lawton on Unsplash (https://unsplash.com/license)
* bacon.jpg
  Photo by Roberto Valdivia on Unsplash (https://unsplash.com/license)
